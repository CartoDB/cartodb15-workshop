var main = function(vis, layers) {

  // TASK 1: Add your viz.json here
  var vizjson = 'https://cartodb15.cartodb.com/api/v2/viz/7c6062ac-9d30-11e5-ab1e-0e3ff518bd15/viz.json';
  var options = {
    shareable: false,
    title: false,
    description: false,
    search: false,
    tiles_loader: true
  };
  cartodb.createVis('map', vizjson, options)
  .done(onVisCreated)
  .error(function(err) { alert('error!'); });
};

var onVisCreated = function(vis, layers) {
  var sublayer = layers[1].getSubLayer(0);

  // TASK 2: Customize the infowindow here

  var originalSQL = sublayer.getSQL();
  var originalCartoCSS = sublayer.getCartoCSS();
  var widgets = new Widgets();

  // TASK 4: Add your first widget here!

  // TASK 8: Add two more widgets

  var stats = addStats();
  loadStats(stats, widgets);

  widgets.each(function(widget) {
    widget.bind('change:activeFilter', function() {

      var sql = generateSQL(originalSQL, widgets);
      var cartoCSS = generateCartoCSS(originalCartoCSS, widgets);

      sublayer.set({
        sql: sql,
        cartocss: cartoCSS
      });

      loadStats(stats, widgets);
    });
  });

  renderStats(stats);
  renderWidgets(widgets);
};

var loadStats = function(stats, widgets) {
  var statsQuery = "SELECT COUNT(price) AS count, ROUND(AVG(price), 2) AS avg, MAX(price) AS max, MIN(price) AS min FROM airbnb_listings";

  console.log("Stats query: ", statsQuery);

  // TASK 7: Modify the query so that stats take the active filters into account

  // TASK 3: Execute a query to fetch some stats and update the stats model
};

var generateSQL = function(originalSQL, widgets) {
  var sql = originalSQL;

  // TASK 5: Customize the SQL so that results are filtered

  console.log("SQL: ", sql);

  return sql;
};

var generateCartoCSS = function(originalCartoCSS, widgets) {
  var cartoCSS = originalCartoCSS;

  // TASK 6: Customize the CartoCSS if filters are active

  console.log("CartoCSS: ", cartoCSS);

  return cartoCSS;
};

window.onload = main;
